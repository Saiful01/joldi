@extends('layouts.default')

@section('content')
    <div class="jumbotron">
        <h1>Complete Login System</h1>
        <p>Click on login button to continue.</p>
    </div>


@endsection

<?php $__env->startSection('title', 'Customer'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Payment Information</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Payment Table</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong><?php echo e(session('success')); ?>!</strong>
                        </div>
                    <?php endif; ?>
                    <?php if(session('failed')): ?>
                        <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong><?php echo e(session('failed')); ?>!</strong>
                        </div>
                    <?php endif; ?>

                    <form class="form-inline" action="/merchant/payments/request" method="post"
                          enctype="multipart/form-data"
                          novalidate="">

                        <div class="form-group">
                            <label style="padding-right: 5px">From</label>
                            <div>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="mm/dd/yyyy" id="datepicker"
                                           name="from_date">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                    <div class="input-group-append">
                                        <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
                                    </div>
                                </div><!-- input-group -->
                            </div>
                        </div>

                        <div class="form-group">
                            <label style="padding-right: 5px;padding-left: 5px">To</label>
                            <div>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="mm/dd/yyyy"
                                           id="datepicker-autoclose" name="to_date">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
                                    </div>
                                </div><!-- input-group -->
                            </div>
                        </div>


                        <div class="form-group">

                            <div class="col-sm-12">
                                <button type="submit" class="btn btn-primary waves-effect waves-light mr-1">
                                    Search
                                </button>
                            </div>
                        </div>

                    </form>


                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Pending Parcels</h4>
                    <p class="card-title-desc"></p>

                    <div class="table-responsive">
                        <table class="table table-bordered mb-0">

                            <thead>
                            <tr>
                                <th>Invoice</th>
                                <th>Parcel Price</th>
                                <th>Total Charge<span style="font-size: 10px">(COD+Delivery)</span></th>
                                <th>Payable Amount</th>

                                <th>Delivery Date</th>
                                <th>Delivered</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $total_price = 0;
                            $total_charge = 0;
                            ?>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($result->parcel_invoice); ?></th>
                                    <th><?php echo e($result->payable_amount); ?></th>
                                    <th><?php echo e($result->cod+$result->delivery_charge); ?></th>
                                    <th><?php echo e($result->payable_amount-($result->cod+$result->delivery_charge)); ?></th>
                                    <th><?php echo e($result->delivery_date); ?></th>
                                    <th><?php echo e($result->updated_at); ?></th>
                                    <?php
                                    $total_price = $total_price + $result->payable_amount;
                                    $total_charge = $total_charge + $result->cod + $result->delivery_charge;
                                    ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>


            <div class="card text-center">
                <div class="card-body">
                    <div class="py-4">

                        <h5 class="text-primary mt-4">Receivable Amount</h5>
                        <p style="line-height: 10px"> Total Amount <?php echo e($total_price); ?></p>
                        <p style="line-height: 10px"> Total Charge: <?php echo e($total_charge); ?></p>
                        <p style="line-height: 10px">Receivable Amount <?php echo e($total_price-$total_charge); ?></p>

                        <form class="custom-validation" action="/merchant/payments/store" method="post"
                              enctype="multipart/form-data"
                              novalidate="">

                            <div class="form-group row" style="display: none">
                                <div class="col-sm-9">
                                    <input class="form-control form-control-lg" type="text" placeholder=""
                                           id="example-text-input-lg" name="parcels" value="<?php echo e($results); ?>"
                                           readonly>
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="hidden" name="payable_amount" value="<?php echo e($total_price-$total_charge); ?>">
                                    <input type="hidden" name="from_date" value="<?php echo e($total_price-$total_charge); ?>">

                                </div>
                            </div>


                            <div class="mt-4">
                                <button type="submit" class="btn btn-primary waves-effect waves-light mr-1">
                                    Payment Request
                                </button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pixonlab/Documents/Joldi-v3/resources/views/merchant/payment/payment_request.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Customer'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Payment Information</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Payment Table</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">
                        Payment Datatable</h4>
                    
                    
                    
                    

                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                           style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Invoice No</th>
                            <th>Delivery date</th>
                            <th>COD</th>
                            <th>Delivery Chrage</th>
                            <th>Totall Amount</th>
                            <th> Current Status</th>

                        </tr>
                        </thead>


                        <tbody>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($res->parcel_invoice); ?></td>
                                <td><?php echo e($res->delivery_date); ?></td>
                                <td><?php echo e($res->cod); ?></td>
                                <td><?php echo e($res->delivery_charge); ?></td>
                                <td><?php echo e($res->total_amount); ?></td>
                                <td><?php echo e($res->delivery_status); ?></td>


                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pixonlab/Documents/Joldi-v3/resources/views/merchant/payment/view.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <h1>Complete Login System</h1>
        <p>Click on login button to continue.</p>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pixonlab/Documents/Joldi-v3/resources/views/common/home/index.blade.php ENDPATH**/ ?>
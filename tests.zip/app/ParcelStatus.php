<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ParcelStatus extends Model
{

    public $timestamps=true;
    protected $guarded=[];
}

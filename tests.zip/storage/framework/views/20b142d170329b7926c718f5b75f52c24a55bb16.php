<?php $__env->startSection('title', 'Parcel View'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Parcel Info</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Parcel Table</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <?php if(Session::has('success')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
                    <?php endif; ?>

                    <?php if(Session::has('failed')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
                    <?php endif; ?>
                        <div class="row mb-3">
                             <div class="col-md-2">
                                 <h4 class="card-title">Parcels</h4>
                             </div>
                            <div class="col-md-2">
                                <form method="post" action="/merchant/same-day/serach" >
                                    <button class="btn  btn-primary waves-effect waves-light">Same Day</button>
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                </form>
                            </div>
                            <div class="col-md-2">
                                <form method="post" action="/merchant/next-day/serach" >
                                    <button class="btn  btn-success waves-effect waves-light">Next Day</button>
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                </form>

                            </div>
                            <div class="col-md-4">
                                <form class="form-inline" method="post" action="/merchant/invoice/serach">
                                    <div class="form-group mx-sm-3 ">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="text" class="form-control" id="inputPassword2" name="invoice" placeholder="Invoice">
                                        <button type="submit" class="btn btn-info form-group ml-2">Search</button>

                                    </div>
                                </form>
                            </div>
                            

                        </div>
                        <form method="post" action="/parcel-all/change">
                            <div id="datatable-buttons_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                <div class="row">
                                    <div class="col-sm-12">

                                        <table class="table mb-0 table-bordered">

                                            <thead>
                                            <tr role="row">
                                                <th><input class="ml-1" type="checkbox" onclick="toggle(this);" /><br />
                                                </th>
                                                <th>Invoice No</th>
                                                
                                                <th>D.Chrage</th>
                                                <th>Amount</th>
                                                <th>Same Day</th>
                                                <th>D. Date</th>
                                                <th>Customer</th>
                                                <th>Phone</th>
                                                <th>Address</th>
                                                <th>Status</th>
                                                <th>P. Status</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>


                                            <tbody>
                                            <?php ($i=1); ?>
                                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                                <tr role="row" class="odd">

                                                    <td><input  type="checkbox" name="parcel_id[]"
                                                                value="<?php echo e($res->parcel_id); ?>"></td>
                                                    <td><?php echo e($res->parcel_invoice); ?></td>
                                                    
                                                    
                                                    <td><?php echo e($res->delivery_charge); ?></td>
                                                    <td><?php echo e($res->total_amount); ?></td>
                                                    <td>
                                                        <?php if($res->is_same_day==true): ?>
                                                            <span class="badge badge-pill badge-info">Yes</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-pill badge-danger">No</span>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($res->is_same_day==true): ?>
                                                            Today
                                                        <?php else: ?>
                                                            <?php echo e($res->delivery_date); ?>


                                                        <?php endif; ?>

                                                    </td>
                                                    <td><?php echo e($res->customer_name); ?></td>
                                                    <td><?php echo e($res->customer_phone); ?></td>
                                                    <td><?php echo e($res->customer_address); ?></td>
                                                    <td>
                                                        <?php if($res->delivery_status=="pending"): ?>
                                                            <span class="badge badge-pill badge-primary">Pending</span>
                                                        <?php elseif($res->delivery_status=="accepted"): ?>
                                                            <span class="badge badge-pill badge-success"> Accepted</span>
                                                        <?php elseif($res->delivery_status=="cancelled"): ?>
                                                            <span class="badge badge-pill badge-danger"> Cancelled</span>
                                                        <?php elseif($res->delivery_status=="on_the-way"): ?>
                                                            <span class="badge badge-pill badge-info"> On The Way</span>
                                                        <?php elseif($res->delivery_status=="delivered"): ?>
                                                            <span class="badge badge-pill badge-success"> Delivered</span>
                                                        <?php elseif($res->delivery_status=="returned"): ?>
                                                            <span class="badge badge-pill badge-warning"> Returned</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-pill badge-warning"> <?php echo e(statusFormat($res->delivery_status)); ?></span>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($res->is_paid_to_merchant=="pending"): ?>
                                                            <span class="badge badge-pill badge-danger">Pending</span>
                                                        <?php elseif($res->is_paid_to_merchant=="requested"): ?>
                                                            <span class="badge badge-pill badge-warning"> Requested</span>
                                                        <?php elseif($res->is_paid_to_merchant=="received"): ?>
                                                            <span class="badge badge-pill badge-success"> Received</span>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group mr-1 mt-2">
                                                            <button type="button" class="btn btn-info btn-sm">Info</button>
                                                            <button type="button"
                                                                    class="btn btn-info btn-sm dropdown-toggle dropdown-toggle-split"
                                                                    data-toggle="dropdown" aria-haspopup="true"
                                                                    aria-expanded="false">
                                                                <i class="mdi mdi-chevron-down"></i>
                                                            </button>
                                                            <div class="dropdown-menu" style="">
                                                                <a class="dropdown-item"
                                                                   href="/merchant/parcel/edit/<?php echo e($res->parcel_id); ?>">Edit</a>
                                                                <a class="dropdown-item"
                                                                   href="/merchant/parcel/delete/<?php echo e($res->parcel_id); ?>">Delete</a>
                                                                <a class="dropdown-item"
                                                                   href="/merchant/parcel/details/<?php echo e($res->parcel_id); ?>">Details</a>
                                                            </div>
                                                        </div>
                                                    </td>

                                                </tr>
                                            </tbody>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>

                            </div>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button name="change" class="btn btn-primary float-right waves-effect waves-light mr-1"
                                    value="1" type="submit" onclick="return confirm('are you sure?')">Print
                            </button>
                            
                            <button name="change" class="btn btn-danger float-right waves-effect waves-light mr-1" value="2"
                                    type="submit" onclick="return confirm('are you sure?')">Delete
                            </button>


                        </form>


                </div>
            </div>
        </div> <!-- end col -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.merchant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workstation\PHP Workstation\joldi\resources\views/merchant/parcel/show.blade.php ENDPATH**/ ?>
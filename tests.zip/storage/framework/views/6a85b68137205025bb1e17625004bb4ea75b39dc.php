<?php $__env->startSection('content'); ?>
    <div class="account-pages my-5 pt-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card overflow-hidden">
                        <div class="bg-success">
                            <div class="text-primary text-center p-4">
                                <h5 class="text-white font-size-20">Welcome Back !</h5>
                                <p class="text-white-50">Reset Your Password to JOLDI.</p>
                                <a href="#" class="logo logo-admin">
                                    <img src="/assets/images/logo.png" height="20" alt="logo">
                                </a>
                            </div>
                        </div>

                        <div class="card-body p-4">
                            <div class="p-3">

                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-success mt-5" role="alert">
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if(Session::has('failed')): ?>
                                    <div class="alert alert-danger mt-5" role="alert">
                                        <?php echo e(Session::get('failed')); ?>

                                    </div>
                                <?php endif; ?>


                                <form class="form-horizontal mt-4" action="/merchant/password-reset" method="post">

                                    <div class="form-group">
                                        <label for="username">Email</label>
                                        <input type="email" class="form-control" id="username" name="merchant_email"
                                               placeholder="">
                                        <input type="hidden" class="form-control" value="<?php echo e(csrf_token()); ?>" name="_token">
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-sm-6 text-right">
                                            <button class="btn btn-success w-md waves-effect waves-light" type="submit">Reset Password
                                            </button>
                                        </div>
                                    </div>


                                </form>

                            </div>
                        </div>

                    </div>

                    <div class="mt-5 text-center">
                        <p>Don't have an account ? <a href="/merchant/registration" class="font-weight-medium text-primary">
                                Signup now </a></p>
                    </div>


                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workstation\PHP Workstation\joldi\resources\views/merchant/login/forgot.blade.php ENDPATH**/ ?>
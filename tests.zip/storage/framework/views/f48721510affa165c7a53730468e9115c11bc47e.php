<?php $__env->startSection('title', 'Payment Request view'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Parcel Information</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Parcel Table</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">
                        Parcel Datatable</h4>
                    
                    
                    
                    

                    <table id="" class="table table-bordered dt-responsive nowrap"
                           style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Merchant Name</th>
                            <th>Phone</th>
                            <th>Amount</th>

                            <th>Parcel Count</th>
                            <th>Status</th>

                            <th>Action</th>

                        </tr>
                        </thead>


                        <tbody>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($res->merchant_name); ?></td>
                                <td><?php echo e($res->merchant_phone); ?></td>
                                <td><?php echo e($res->payable_amount); ?></td>

                                <td><?php echo e(count(json_decode($res->parcels,true))); ?></td>
                                <td>
                                    <?php if($res->paid_status=="pending"): ?>

                                        <span class="badge badge-warning">  <?php echo e($res->paid_status); ?></span>
                                    <?php elseif($res->paid_status=="rejected"): ?>

                                        <span class="badge badge-danger">  <?php echo e($res->paid_status); ?></span>
                                    <?php else: ?>

                                        <span class="badge badge-success">  <?php echo e($res->paid_status); ?></span>
                                    <?php endif; ?>


                                </td>
                                <td>
                                    <div class="btn-group mr-1 mt-2">
                                        <button type="button" class="btn btn-info btn-sm">Action</button>
                                        <button type="button"
                                                class="btn btn-info btn-sm dropdown-toggle dropdown-toggle-split"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="mdi mdi-chevron-down"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                            <?php if($res->paid_status=="pending"): ?>
                                                <a class="dropdown-item"
                                                   href="/admin/view/payments-request/approve/<?php echo e($res->id); ?>">Approve</a>
                                                <a class="dropdown-item"
                                                   href="/admin/view/payments-request/cancel/<?php echo e($res->id); ?>">Cancel</a>
                                            <?php elseif($res->paid_status=="rejected"): ?>
                                                <a class="dropdown-item"
                                                   href="/admin/view/payments-request/approve/<?php echo e($res->id); ?>">Approve</a>

                                            <?php else: ?>
                                                <a class="dropdown-item"
                                                   href="#">Already <?php echo e($res->paid_status); ?></a>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </td>


                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workstation\PHP Workstation\joldi\resources\views/admin/payment/payment_request.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Parcel Details'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Parcel Info</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Parcel Table</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <div>
                                <div class="">

                                    <div class="d-print-none">
                                        <div class="float-right">
                                            <a href="javascript:window.print()"
                                               class="btn btn-sm btn-success waves-effect waves-light"><i
                                                        class="fa fa-print"></i> Print</a>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div> <!-- end row -->

                    <div class="row">
                        <div class="col-12">
                            
                            <div class="row">
                                <?php $__currentLoopData = $parcel_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6">

                                        <div class="row">
                                            <div class="col-md-6 mt-3">
                                                <address>
                                                    <strong>Billed To:</strong>
                                                    <hr>
                                                    <span class="font-weight-bold mr-2">Name:</span> <?php echo e($result->customer_name); ?>

                                                    <br>
                                                    <span class="font-weight-bold mr-2">Phone:</span><?php echo e($result->customer_name); ?>

                                                    <br>
                                                    <span class="font-weight-bold mr-2">Address:</span><?php echo e($result->customer_address); ?>

                                                </address>

                                            </div>
                                            <div class="col-md-6">
                                                <?php echo QrCode::size(150)->generate($result->parcel_invoice);; ?>


                                            </div>
                                        </div>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>
                        </div>

                    </div>
                </div>
            </div> <!-- end col -->
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.merchant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workstation\PHP Workstation\joldi\resources\views/merchant/parcel/print_qr.blade.php ENDPATH**/ ?>
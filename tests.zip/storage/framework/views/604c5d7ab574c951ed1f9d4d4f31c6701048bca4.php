<?php $__env->startSection('title', 'View Payment Status'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Payment Information</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Payment Table</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">
                        Payment Datatable</h4>
                    
                    
                    
                    

                    <table id="datatablef" class="table table-bordered dt-responsive nowrap"
                           style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Payable Amount</th>
                            <th>Payment for</th>
                            <th>Status</th>
                            <th>Merchant Approval</th>
                            <th>Approval Date</th>

                        </tr>
                        </thead>


                        <tbody>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($res->payable_amount); ?></td>


                                <td><a href="#"><?php echo e(count(json_decode($res->parcels))); ?> Parcel</a> </td>
                                <td>
                                <?php if($res->paid_status=='pending'): ?>
                                        <span class="badge badge-pill badge-warning">Pending</span>
                                    <?php elseif($res->paid_status=='cancel'): ?>

                                        <span class="badge badge-pill badge-danger">Cancel</span>
                                    <?php elseif($res->paid_status=='approved'): ?>
                                        <span class="badge badge-pill badge-success">Approved</span>
                                    <?php endif; ?>

                                </td>
                                <td>
                                    <?php if($res->is_merchant_approved): ?>
                                        <span class="badge badge-pill badge-success">Approved</span>

                                    <?php else: ?>
                                        <span class="badge badge-pill badge-warning">Not Approved</span>
                                    <?php endif; ?>

                                </td>
                                <td><?php echo e($res->updated_at); ?></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.merchant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workstation\PHP Workstation\joldi\resources\views/merchant/payment/view.blade.php ENDPATH**/ ?>
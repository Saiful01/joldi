<?php $__env->startSection('title', 'Parcel Create'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Parcel</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Add New Parcel, <span style="color: red">You are adding Parcel for <?php echo e(\Illuminate\Support\Facades\Session::get('shop_name')); ?></span>
                            <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#myModal">Change
                            </button>
                        </a></li>
                    


                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->

    <div class="row" ng-controller="parcelController">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>


                    <?php if(Session::has('success')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('success')); ?></p>
                    <?php endif; ?>

                    <?php if(Session::has('failed')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('failed')); ?></p>
                    <?php endif; ?>

                    <form class="custom-validation" action="/merchant/parcel/store" method="post"
                          enctype="multipart/form-data"
                          novalidate="">
                        <div class="row">
                            <div class="col-md-4">
                                <h5 class=" mb-3"><?php echo e($invoice); ?> </h5>
                                <hr>
                                <input class="form-control form-control-lg" type="hidden" placeholder=""
                                       id="example-text-input-lg" name="parcel_invoice" value="<?php echo e($invoice); ?>"
                                       readonly>

                                
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" name="shop_id" value="<?php echo e(Session::get('shop_id')); ?>">
                                <input type="hidden" name="is_same_day" value="<?php echo e($is_same_day); ?>">

                                

                                <div class="form-group row">
                                    
                                    <div class="col-sm-12">
                                        <select ng-model="parcel_type" class="form-control form-control-lg"
                                                name="parcel_type_id" ng-change="update()">
                                            
                                            <option value="" selected disabled hidden>ওজন</option>
                                            <option ng-repeat="x in parcels" value="{{x.parcel_type_id}}"
                                                    ng-selected="1">
                                                {{x.title}}
                                            </option>
                                        </select>


                                    </div>
                                </div>
                                <div class="form-group row" style="display: none;">
                                    
                                    <div class="col-sm-12">
                                        <input class="form-control form-control-lg" type="text" placeholder="0"
                                               value="<?php echo e($cod_charge); ?>" name="cod" ng-model="cod"
                                        >
                                    </div>
                                </div>
                                <div class="form-group row" style="display: none">
                                    <label for="delivery_charge" class="col-sm-3 col-form-label">Delivery Charge</label>
                                    <div class="col-sm-12">
                                        <input class="form-control form-control-lg" type="text"
                                               placeholder="ডেলিভারি চার্জ"
                                               id="delivery_charge" name="delivery_charge" ng-model="delivery_charge"
                                               readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    
                                    <div class="col-sm-12">
                                        <input class="form-control form-control-lg" type="number"
                                               placeholder="পার্সেল  প্রাইস"
                                               id="example-text-input-lg" name="payable_amount"
                                               ng-model="payable_amount" ng-change="totalPriceCalcualtion()">
                                    </div>
                                </div>
                                     <div class="form-group row" style="display: none">
                                            <label for="example-text-input-lg" class="col-sm-3 col-form-label">Total
                                                Amount</label>
                                         <div class="col-sm-12">
                                             <input class="form-control form-control-lg" type="text"
                                                    placeholder="মোট টাকা"
                                                    id="example-text-input-lg" name="total_amount" ng-model="total_amount">
                                         </div>
                                     </div>
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                
                                
                                
                                
                                

                                


                                <div class="form-group row" style="display: none;">
                                    
                                    <div class="col-sm-12">
                                        <input class="form-control form-control-lg" type="hidden" name="is_same_day"
                                               value="<?php echo e($is_same_day); ?>">
                                    </div>
                                </div>


                            </div>
                            <div class="col-md-4">
                                <h5 class=" mb-3">Customer Information </h5>
                                <hr>


                                <div class="form-group row">
                                    
                                    <div class="col-sm-12">
                                        <input class="form-control form-control-lg" type="text"
                                               placeholder="কাস্টমার নাম"
                                               id="example-text-input-lg" name="customer_name">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    
                                    <div class="col-sm-12">
                                        <input class="form-control form-control-lg" type="text"
                                               placeholder=" কাস্টমার ফোন"
                                               id="example-text-input-lg" name="customer_phone">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    
                                    <div class="col-sm-12">


                                        <select ng-model="area_id" class="form-control form-control-lg"
                                                name="area_id" ng-change="updateArea()">
                                            
                                            <option value="" selected disabled hidden>Area</option>
                                            <option ng-repeat="x in areas" value="{{x.area_id}}"
                                                    ng-selected="1">
                                                {{x.area_name}}
                                            </option>
                                        </select>

                                    </div>
                                </div>
                                <div class="form-group row">
                                    
                                    <div class="col-sm-12">
                               <textarea class="form-control form-control-lg" type="text" placeholder="কাস্টমার ঠিকানা"
                                         id="example-text-input-lg" name="customer_address"></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    
                                    
                                    <div class="col-sm-12">
                               <textarea class="form-control form-control-lg" type="text"
                                         placeholder="কোনো বিশেষ নির্দেশনা"
                                         id="example-text-input-lg" name="parcel_notes"></textarea>
                                    </div>
                                </div>


                                <div class="form-group row">
                                    
                                    <div class="col-sm-12">
                                        <button type="submit" class="btn btn-primary waves-effect waves-light mr-1">
                                            Submit
                                        </button>
                                        
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h6>ডেলিভারি চার্জ বিস্তারিত </h6>
                                        <hr>
                                    </div>
                                    <div class="card-body" style="background-color: rgba(210,210,210,0.47)">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <h6>Cash Collection</h6>
                                                <h6>Delivery Charge</h6>
                                                <h6>Cod Charge</h6>
                                                <h6>Area Charge</h6>
                                                <hr>
                                                <h6>Total Payble Amount</h6>
                                            </div>
                                            <div class="col-md-4">
                                                <h6 ng-bind="payable_amount">Tk. 100</h6>
                                                <h6 ng-bind="delivery_charge">Tk. 60</h6>
                                                <h6 ng-bind="cod_charge">Tk. 0</h6>
                                                <h6 ng-bind="area_charge">Tk. 0</h6>
                                                <hr>
                                                <h6 ng-bind="total_amount">Tk. 40</h6>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </form>


                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->


    <!-- The Modal -->
    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Shop Selection</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">

                    <form action="/merchant/current/shop">
                        <div class="form-group">
                            <label for="sel1">Select Shop:</label>
                            <select class="form-control" name="shop">
                                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($shop->shop_id); ?>"><?php echo e($shop->shop_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>

                </div>
            </div>
        </div>
    </div>


    <script>
        var app = angular.module('parcelCreateApp', []);
        app.controller('parcelController', function ($scope, $http) {

            $scope.delivery_charge = 0;
            $scope.payable_amount = 0;
            $scope.total_amount = 0;
            $scope.area_charge = 0;
            $scope.cod_charge = '<?php echo $cod_charge?>';
            $scope.cod = '<?php echo $cod_charge?>';

            $http.get('/get-parcel-type', {}).then(function success(e) {

                console.log(e.data);
                $scope.parcels = e.data;
            });

            $http.get('/get-area', {}).then(function success(e) {

                console.log(e.data);
                $scope.areas = e.data;
            });

            $scope.updateArea = function () {
                console.log($scope.area_id+'---');

                $http.get('/get-area-charge/' + $scope.area_id, {}).then(function success(e) {

                    console.log(e.data.value);

                    $scope.area_charge = parseFloat(e.data.value);
                    $scope.total_amount = parseFloat($scope.delivery_charge) + parseFloat($scope.payable_amount) + parseFloat($scope.cod_charge)+parseFloat($scope.area_charge);

                    console.log($scope+'--');
                });

            };

            $scope.update = function () {

                $http.get('/get-delivery-charge/' + $scope.parcel_type, {}).then(function success(e) {

                    console.log(e.data.charge);

                    $scope.delivery_charge = parseFloat(e.data.charge);
                    $scope.total_amount = parseFloat(e.data.charge) + parseFloat($scope.payable_amount) + parseFloat($scope.cod_charge)+parseFloat($scope.area_charge);
                    ;

                    console.log($scope.total_amount);
                });

            };


            $scope.totalPriceCalcualtion = function () {

                $scope.total_amount = parseFloat($scope.delivery_charge) + parseFloat($scope.payable_amount) + parseFloat($scope.cod_charge)+parseFloat($scope.area_charge);

                console.log("hhhh" + parseFloat($scope.delivery_charge) + parseFloat($scope.payable_amount));

                //parseFloat($scope.delivery_charge) + parseFloat($scope.payable_amount) + parseFloat($scope.cod);


            }
        });


        function isSameDayTrue() {
            //var is_same_day = document.getElementById('is_same_day').value;
            document.getElementById('delivery_date').style.display = 'block';

            //console.log(document.getElementById("is_same_day").value);
        }

        function isSameDayFalse() {
            //var is_same_day = document.getElementById('is_same_day').value;
            document.getElementById('delivery_date').style.display = 'none';

            //console.log(document.getElementById("is_same_day").value);
        }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.merchant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workstation\PHP Workstation\joldi\resources\views/merchant/parcel/index.blade.php ENDPATH**/ ?>
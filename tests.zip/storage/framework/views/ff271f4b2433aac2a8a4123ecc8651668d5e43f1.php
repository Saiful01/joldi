<h1>Hi! <?php echo e($name); ?></h1>
<p><?php echo e($body); ?></p>
<?php /**PATH D:\Workstation\PHP Workstation\joldi\resources\views/mail.blade.php ENDPATH**/ ?>
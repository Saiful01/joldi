<?php $__env->startSection('title', 'Parcel Details'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Parcel Info</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Parcel Table</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <div class="row">
                        <div class="col-12">
                            <div class="invoice-title">
                                <h4 class="float-right font-size-16"><strong>Invoice
                                        # <?php echo e($result->parcel_invoice); ?></strong></h4>
                                <h3 class="mt-0">
                                    <img src="/assets/images/logo.png" alt="logo" height="36">
                                </h3>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-6">
                                    <address>
                                        <strong>Billed To:</strong><br>
                                        <?php echo e($result->customer_name); ?><br>
                                        <?php echo e($result->customer_name); ?><br>
                                        <?php echo e($result->customer_address); ?>

                                    </address>
                                </div>
                                <div class="col-6 text-right">


                                    <?php echo QrCode::size(150)->generate($result->parcel_invoice);; ?>



                                </div>
                            </div>

                            <div class="row">
                                <div class="col-6 mt-4">
                                    <address>
                                        <strong>Charge:</strong><br>
                                        Amount: <?php echo e($result->payable_amount); ?><br>
                                        Charge: <?php echo e($result->delivery_charge); ?><br>
                                        Total Amount: <?php echo e($result->total_amount); ?><br>
                                        Status: <span class="text-primary"><?php echo e(statusFormat($result->delivery_status)); ?></span><br>
                                        Date: <?php echo e($result->delivery_date); ?><br>
                                    </address>
                                </div>
                                <div class="col-6 mt-4 text-right">

                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div>
                                <div class="">

                                    <div class="d-print-none">
                                        <div class="float-right">
                                            <a href="javascript:window.print()"
                                               class="btn btn-success waves-effect waves-light"><i
                                                        class="fa fa-print"></i> Print</a>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div> <!-- end row -->

                </div>
            </div>
        </div> <!-- end col -->
    </div>
    <div class="row">
        <div class="col-12">

            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4">Activity</h4>
                    <ol class="activity-feed">


                        <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="feed-item">
                                <div class="feed-item-list">
                                    <span class="date"><?php echo e($history->created_at); ?></span>
                                    <span class="activity-text badge badge-info"><?php echo e(statusFormat($history->parcel_status)); ?></span>
                                    <p><?php echo e($history->notes); ?></p>
                                </div>
                            </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ol>

                </div>
            </div>

        </div> <!-- end col -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workstation\PHP Workstation\joldi\resources\views/admin/consignment/details.blade.php ENDPATH**/ ?>
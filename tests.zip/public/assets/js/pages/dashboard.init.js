

$(".peity-donut").each(function () {
    $(this).peity("donut", $(this).data())
}), $(".peity-line").each(function () {
    $(this).peity("line", $(this).data())
});

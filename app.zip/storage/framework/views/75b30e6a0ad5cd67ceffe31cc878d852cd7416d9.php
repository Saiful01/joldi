<?php $__env->startSection('title', 'Area manage'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Area</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Area Table</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">Area Datatable</h4>
                    <a href="/admin/area/create" type="button" class="btn btn-success float-right"> +new</a>
                    
                    
                    
                    

                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                           style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th> Area Name</th>
                            <th>Address</th>
                            <th>Action</th>
                        </tr>
                        </thead>


                        <tbody>
                        <tr>
                            <?php ($i=1); ?>
                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($res->area_name); ?></td>
                                <td><?php echo e($res->area_address); ?></td>
                                <td>
                                    <div class="btn-group mr-1 mt-2">
                                        <button type="button" class="btn btn-info btn-sm">Action</button>
                                        <button type="button"
                                                class="btn btn-info btn-sm dropdown-toggle dropdown-toggle-split"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="mdi mdi-chevron-down"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="/admin/area/edit/<?php echo e($res->area_id); ?>">Edit</a>
                                            <a class="dropdown-item" href="/admin/area/delete/<?php echo e($res->area_id); ?>">Delete</a>
                                        </div>
                                    </div>
                                </td>


                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Babu09\Downloads\joldi\resources\views/admin/area/view.blade.php ENDPATH**/ ?>
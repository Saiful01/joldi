<?php $__env->startSection('title', 'Parcel Create'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Parcel</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Add New Parcel, <span style="color: red">You are adding Parcel for <?php echo e(\Illuminate\Support\Facades\Session::get('shop_name')); ?></span>
                            <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#myModal">Change</button>
                        </a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->

    <div class="row" ng-controller="parcelController">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>


                    <?php if(Session::has('success')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('success')); ?></p>
                    <?php endif; ?>

                    <?php if(Session::has('failed')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('failed')); ?></p>
                    <?php endif; ?>

                    <form class="custom-validation" action="/merchant/parcel/store" method="post"
                          enctype="multipart/form-data"
                          novalidate="">
                        <div class="row">
                            <div class="col-md-6">
                                <h5 class=" mb-3">Parcel Information </h5>
                                <hr>

                                <div class="form-group row">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label">Invoice</label>
                                    <div class="col-sm-9">
                                        <input class="form-control form-control-lg" type="text" placeholder=""
                                               id="example-text-input-lg" name="parcel_invoice" value="<?php echo e($invoice); ?>"
                                               readonly>
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="hidden" name="shop_id" value="<?php echo e(Session::get('shop_id')); ?>">
                                        <input type="hidden" name="is_same_day" value="<?php echo e($is_same_day); ?>">
                                       


                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label">Parcel
                                        Title</label>
                                    <div class="col-sm-9">
                                        <input class="form-control form-control-lg" type="text"
                                               placeholder=""
                                               id="example-text-input-lg" name="parcel_title">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label">Parcel
                                        Types</label>
                                    <div class="col-sm-9">
                                        <select ng-model="parcel_type" class="form-control form-control-lg"
                                                name="parcel_type_id" ng-change="update()">
                                            

                                            <option ng-repeat="x in parcels" value="{{x.parcel_type_id}}"
                                                    ng-selected="1">
                                                {{x.title}}
                                            </option>
                                        </select>


                                    </div>
                                </div>
                                <div class="form-group row" style="display: none;">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label">COD</label>
                                    <div class="col-sm-9">
                                        <input class="form-control form-control-lg" type="text" placeholder="0"
                                               value="<?php echo e($cod_charge); ?>" name="cod"
                                               readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="delivery_charge" class="col-sm-3 col-form-label">Delivery Charge</label>
                                    <div class="col-sm-9">
                                        <input class="form-control form-control-lg" type="text" placeholder="0"
                                               id="delivery_charge" name="delivery_charge" ng-model="delivery_charge"
                                               readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label">Total
                                        Amount</label>
                                    <div class="col-sm-9">
                                        <input class="form-control form-control-lg" type="text"
                                               placeholder="Total Amount"
                                               id="example-text-input-lg" name="total_amount" ng-model="total_amount">
                                    </div>
                                </div>

























                            </div>
                            <div class="col-md-6">
                                <h5 class=" mb-3">Customer Information </h5>
                                <hr>
                                <div class="form-group row">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label">Parcel
                                        Price</label>
                                    <div class="col-sm-9">
                                        <input class="form-control form-control-lg" type="text"
                                               placeholder="Parcel price"
                                               id="example-text-input-lg" name="payable_amount"
                                               ng-model="payable_amount" ng-change="totalPriceCalcualtion()">
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label">Customer
                                        Name</label>
                                    <div class="col-sm-9">
                                        <input class="form-control form-control-lg" type="text" placeholder="Name"
                                               id="example-text-input-lg" name="customer_name">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label">Customer
                                        Phone</label>
                                    <div class="col-sm-9">
                                        <input class="form-control form-control-lg" type="text" placeholder="Phone"
                                               id="example-text-input-lg" name="customer_phone">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label">Customer
                                        Area</label>
                                    <div class="col-sm-9">

                                        <select class="form-control form-control-lg"
                                                name="area_id">
                                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($area->area_id); ?>"><?php echo e($area->area_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label">Customer
                                        Address</label>
                                    <div class="col-sm-9">
                               <textarea class="form-control form-control-lg" type="text" placeholder="Customer Address"
                                         id="example-text-input-lg" name="customer_address"></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label">
                                        Note</label>
                                    <div class="col-sm-9">
                               <textarea class="form-control form-control-lg" type="text" placeholder="Write Note..."
                                         id="example-text-input-lg" name="parcel_notes"></textarea>
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <label for="example-text-input-lg" class="col-sm-3 col-form-label"></label>
                                    <div class="col-sm-9">
                                        <button type="submit" class="btn btn-primary waves-effect waves-light mr-1">
                                            Submit
                                        </button>
                                        <button type="reset" class="btn btn-secondary waves-effect">
                                            Reset
                                        </button>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </form>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->


    <!-- The Modal -->
    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Modal Heading</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">

                    <form action="/merchant/current/shop">
                        <div class="form-group">
                            <label for="sel1">Select Shop:</label>
                            <select class="form-control" name="shop">
                                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($shop->shop_id); ?>"><?php echo e($shop->shop_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>

                </div>
            </div>
        </div>
    </div>


    <script>
        var app = angular.module('parcelCreateApp', []);
        app.controller('parcelController', function ($scope, $http) {

            $scope.delivery_charge = 0;
            $scope.payable_amount = 0;
            $http.get('/get-parcel-type', {}).then(function success(e) {

                console.log(e.data);
                $scope.parcels = e.data;
            });

            $scope.update = function () {

                $http.get('/get-delivery-charge/' + $scope.parcel_type, {}).then(function success(e) {

                    console.log(e.data.charge);

                    $scope.delivery_charge = parseFloat(e.data.charge);
                    $scope.total_amount = parseFloat(e.data.charge) + parseFloat($scope.payable_amount);

                    console.log($scope.total_amount);
                });

            };


            $scope.totalPriceCalcualtion = function () {

                $scope.total_amount = parseFloat($scope.delivery_charge) + parseFloat($scope.payable_amount);

                console.log(parseFloat($scope.delivery_charge) + parseFloat($scope.payable_amount));

                //parseFloat($scope.delivery_charge) + parseFloat($scope.payable_amount) + parseFloat($scope.cod);


            }
        });


        function isSameDayTrue() {
            //var is_same_day = document.getElementById('is_same_day').value;
            document.getElementById('delivery_date').style.display = 'block';

            //console.log(document.getElementById("is_same_day").value);
        }

        function isSameDayFalse() {
            //var is_same_day = document.getElementById('is_same_day').value;
            document.getElementById('delivery_date').style.display = 'none';

            //console.log(document.getElementById("is_same_day").value);
        }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.merchant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Babu09\Downloads\joldi\resources\views/merchant/parcel/index.blade.php ENDPATH**/ ?>
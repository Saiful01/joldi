<?php $__env->startSection('title', 'All Consignment'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Parcel Info</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Parcel Table</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <?php if(Session::has('success')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
                    <?php endif; ?>

                    <?php if(Session::has('failed')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
                    <?php endif; ?>
                    <h4 class="card-title">Parcels</h4>
                    <p class="card-title-desc">
                    </p>

                    <div id="datatable-buttons_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                        <div class="row">
                            <div class="col-sm-12">

                                <table class="table mb-0">

                                    <thead>
                                    <tr role="row">
                                        <th>Invoice No</th>
                                        <th>COD</th>
                                        <th>D.Chrage</th>
                                        <th>Amount</th>
                                        <th>Same Day</th>
                                        <th>D. Date</th>
                                        <th>Deliveryman</th>
                                        <th>Customer</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>Status</th>
                                        <th>P. Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>


                                    <tbody>
                                    <?php ($i=1); ?>
                                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <tr role="row" class="odd">

                                            <th>#<?php echo e($res->parcel_invoice); ?></th>
                                            
                                            <td><?php echo e($res->cod); ?></td>
                                            <td><?php echo e($res->delivery_charge); ?></td>
                                            <td><?php echo e($res->total_amount); ?></td>
                                            <td>
                                                <?php if($res->is_same_day==true): ?>
                                                    <span class="badge badge-pill badge-info">Yes</span>
                                                <?php else: ?>
                                                    <span class="badge badge-pill badge-danger">No</span>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($res->is_same_day==true): ?>
                                                    Today
                                                <?php else: ?>
                                                    <?php echo e($res->delivery_date); ?>


                                                <?php endif; ?>

                                            </td>
                                            <td>


                                                <?php if($res->delivery_man_id==null): ?>
                                                    <div class="col-sm-6 col-md-3">
                                                        <div class="text-center">
                                                            <!-- Small modal -->
                                                            <button type="button"
                                                                    class="btn btn-sm btn-primary waves-effect waves-light"
                                                                    data-toggle="modal"
                                                                    data-target=".modal-id<?php echo e($res->parcel_id); ?>">Assign
                                                            </button>
                                                        </div>

                                                        <div class="modal fade modal-id<?php echo e($res->parcel_id); ?>"
                                                             tabindex="-1"
                                                             role="dialog" aria-labelledby="mySmallModalLabel"
                                                             style="display: none;" aria-hidden="true">
                                                            <div class="modal-dialog modal-sm">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title mt-0"
                                                                            id="mySmallModalLabel">Assign
                                                                            Deliveryman</h5>
                                                                        <button type="button" class="close"
                                                                                data-dismiss="modal" aria-hidden="true">
                                                                            ×
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">

                                                                        <form method="get"
                                                                              action="/admin/parcel/assign-deliveryman">
                                                                            <div class="form-group">
                                                                                <label class="control-label">Select
                                                                                    Deliveryman</label>

                                                                                <input name="_token"
                                                                                       value="<?php echo e(csrf_token()); ?>"
                                                                                       type="hidden"/>
                                                                                <input name="parcel_id"
                                                                                       value="<?php echo e($res->parcel_id); ?>"
                                                                                       type="hidden"/>
                                                                                <select class="form-control select2"
                                                                                        name="delivery_man_id">
                                                                                    <option>Select</option>

                                                                                    <?php $__currentLoopData = $delivery_mans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery_man): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option value="<?php echo e($delivery_man->delivery_man_id); ?>"><?php echo e($delivery_man->delivery_man_name); ?></option>

                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                                </select>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                
                                                                                <button type="submit"
                                                                                        class="btn btn-block btn-primary btn-sm waves-effect waves-light float-right">
                                                                                    Save
                                                                                </button>
                                                                            </div>


                                                                        </form>


                                                                    </div>
                                                                </div><!-- /.modal-content -->
                                                            </div><!-- /.modal-dialog -->
                                                        </div><!-- /.modal -->
                                                    </div>
                                                <?php else: ?>
                                                    <?php echo e($res->delivery_man_name); ?>

                                                <?php endif; ?>

                                            </td>


                                            <td><?php echo e($res->customer_name); ?></td>
                                            <td><?php echo e($res->customer_phone); ?></td>
                                            <td><?php echo e($res->customer_address); ?></td>
                                            <td>
                                                <?php if($res->delivery_status=="pending"): ?>
                                                    <span class="badge badge-pill badge-primary">Pending</span>
                                                <?php elseif($res->delivery_status=="accepted"): ?>
                                                    <span class="badge badge-pill badge-secondary"> Accepted</span>
                                                <?php elseif($res->delivery_status=="cancelled"): ?>
                                                    <span class="badge badge-pill badge-danger"> Cancelled</span>
                                                <?php elseif($res->delivery_status=="on_the_way"): ?>
                                                    <span class="badge badge-pill badge-info"> On The Way</span>
                                                <?php elseif($res->delivery_status=="delivered"): ?>
                                                    <span class="badge badge-pill badge-success"> Delivered</span>
                                                <?php elseif($res->delivery_status=="returned"): ?>
                                                    <span class="badge badge-pill badge-warning"> Returned</span>
                                                <?php elseif($res->delivery_status=="returned_to_admin"): ?>
                                                    <span class="badge badge-pill badge-success"> Returned To Admin</span>
                                                <?php elseif($res->delivery_status=="partial_delivered"): ?>
                                                    <span class="badge badge-pill badge-warning"> Partial Delivered</span>

                                                    <button type="button" class="btn btn-primary" data-toggle="modal"
                                                            data-target=".receive-modal<?php echo e($res->parcel_id); ?>">Receive
                                                    </button>

                                                    <div class="modal fade receive-modal<?php echo e($res->parcel_id); ?>"
                                                         tabindex="-1"
                                                         role="dialog" aria-labelledby="mySmallModalLabel"
                                                         style="display: none;" aria-hidden="true">
                                                        <div class="modal-dialog modal-sm">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title mt-0"
                                                                        id="mySmallModalLabel">Receive Product</h5>
                                                                    <button type="button" class="close"
                                                                            data-dismiss="modal" aria-hidden="true">
                                                                        ×
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">

                                                                    <form method="get"
                                                                          action="/admin/parcel/receive-by-admin">
                                                                        <div class="form-group">
                                                                            <label class="control-label">Notes</label>

                                                                            <input name="_token"
                                                                                   value="<?php echo e(csrf_token()); ?>"
                                                                                   type="hidden"/>
                                                                            <input name="parcel_id"
                                                                                   value="<?php echo e($res->parcel_id); ?>"
                                                                                   type="hidden"/>


                                                                            <textarea class="form-control"
                                                                                      name="notes"></textarea>

                                                                        </div>

                                                                        <div class="form-group">
                                                                            
                                                                            <button type="submit"
                                                                                    class="btn btn-block btn-primary btn-sm waves-effect waves-light float-right">
                                                                                Save
                                                                            </button>
                                                                        </div>


                                                                    </form>


                                                                </div>
                                                            </div><!-- /.modal-content -->
                                                        </div><!-- /.modal-dialog -->
                                                    </div><!-- /.modal -->


                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($res->is_paid_to_merchant=="pending"): ?>
                                                    <span class="badge badge-pill badge-danger">Pending</span>
                                                <?php elseif($res->is_paid_to_merchant=="requested"): ?>
                                                    <span class="badge badge-pill badge-warning"> Requested</span>
                                                <?php elseif($res->is_paid_to_merchant=="received"): ?>
                                                    <span class="badge badge-pill badge-success"> Received</span>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group mr-1 mt-2">
                                                    <button type="button" class="btn btn-info btn-sm">Info</button>
                                                    <button type="button"
                                                            class="btn btn-info btn-sm dropdown-toggle dropdown-toggle-split"
                                                            data-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                        <i class="mdi mdi-chevron-down"></i>
                                                    </button>
                                                    <div class="dropdown-menu" style="">
                                                        
                                                        
                                                        
                                                        
                                                        <a class="dropdown-item"
                                                           href="/admin/parcel/details/<?php echo e($res->parcel_id); ?>">Details</a>
                                                    </div>
                                                </div>
                                            </td>

                                        </tr>
                                    </tbody>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div> <!-- end col -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Babu09\Downloads\joldi\resources\views/admin/consignment/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Merchant Profile</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Merchant Profile Setting</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-md-10 col-lg-10 col-xl-6">

            <!-- Simple card -->
            <div class="card">
                <img class="card-img-top img-fluid" src="/merchant/<?php echo e($result->merchant_image); ?>" alt="Card image cap" style="width: 100px;" width="100px">
                <div class="card-body">
                    <h4> Name: <?php echo e($result->merchant_name); ?></h4>
                    <h6> Phone: <?php echo e($result->merchant_phone); ?></h6>
                    <h6> Email: <?php echo e($result->merchant_email); ?></h6>
                    <h6> Active Status: <?php if($result->active_status==0): ?> NO <?php else: ?> Yes <?php endif; ?></h6>
                    <h6> COD Enable: <?php if($result->is_cod_enable==0): ?> No <?php else: ?> yes <?php endif; ?></h6>
                    <h6> COD Charge: <?php echo e($result->cod_charge); ?></h6>
                    <h6> Area: <?php echo e($result->area_name); ?></h6>
                    <a href="/merchant/setting/edit/<?php echo e($result->merchant_id); ?>"
                       class="btn btn-primary waves-effect waves-light">Edit</a>
                </div>
            </div>

        </div>
        <div class="col-md-6 col-lg-6">

            <!-- Simple card -->
            <div class="card">
                <div class="card-title">
                    <h5 class="mt-2 text-center text-success"> Payment Methoed Details</h5>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $payment_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h6> <strong>Payment Method :</strong> <?php echo e($data->payment_methoed_name); ?></h6>
                        <h6> <strong>Account Number:</strong> <?php echo e($data->account_number); ?></h6>
                        <h6> <strong>Branch Addrss:</strong> <?php echo e($data->branch_address); ?></h6>
                        <h6> <strong>Payee Name:</strong> <?php echo e($data->payee_name); ?></h6>

                        <a href="/merchant/paymentmethoed/edit/<?php echo e($data->paymentmethoed_id); ?>"
                           class="btn btn-primary btn-sm waves-effect waves-light">Edit</a>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <a href="/merchant/paymentmethoed/create"
                       class="btn btn-info btn-sm waves-effect waves-light">+create</a>
                </div>
            </div>

        </div>


    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.merchant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Babu09\Downloads\joldi\resources\views/merchant/setting/index.blade.php ENDPATH**/ ?>
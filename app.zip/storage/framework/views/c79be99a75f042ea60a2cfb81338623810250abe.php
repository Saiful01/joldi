<?php $__env->startSection('title', 'Merchant Create'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Merchants</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Merchant Table</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <?php if(Session::has('success')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
                    <?php endif; ?>

                    <?php if(Session::has('failed')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
                    <?php endif; ?>


                    <h4 class="card-title">
                        Merchant List</h4>

                    <table id="" class="table table-bordered dt-responsive nowrap"
                           style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>COD</th>
                            <th>COD Charge</th>
                            <th>Status</th>
                            <th>Action</th>

                        </tr>
                        </thead>


                        <tbody>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($res->merchant_name); ?></td>
                                <td><?php echo e($res->merchant_phone); ?></td>
                                <td><?php echo e($res->merchant_email); ?></td>

                                <td>
                                    <?php if($res->is_cod_enable): ?>
                                        <span class="badge badge-success">Yes</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">No</span>
                                    <?php endif; ?>
                                </td>


                                <td><?php echo e($res->cod_charge); ?></td>

                                <td>
                                    <?php if($res->active_status): ?>
                                        <span class="badge badge-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>

                                <td>

                                    <div class="btn-group mr-1 mt-2">
                                        <button type="button" class="btn btn-info btn-sm">Action</button>
                                        <button type="button"
                                                class="btn btn-info btn-sm dropdown-toggle dropdown-toggle-split"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="mdi mdi-chevron-down"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="/admin/merchant/edit/<?php echo e($res->merchant_id); ?>">Edit</a>
                                            <a class="dropdown-item" href="/admin/merchant/profile/<?php echo e($res->merchant_id); ?>">Profile</a>
                                            <?php if($res->active_status): ?>
                                                <a class="dropdown-item" href="/admin/merchant/inactive/<?php echo e($res->merchant_id); ?>">Inactive</a>
                                            <?php else: ?>
                                                <a class="dropdown-item" href="/admin/merchant/activate/<?php echo e($res->merchant_id); ?>">Activate</a>
                                            <?php endif; ?>
                                        </div>
                                    </div>


                                </td>


                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Babu09\Downloads\joldi\resources\views/admin/merchant/index.blade.php ENDPATH**/ ?>
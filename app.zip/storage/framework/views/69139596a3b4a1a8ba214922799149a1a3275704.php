<?php $__env->startSection('title', 'Merchant Profile'); ?>

<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="page-title-box">
                <h4 class="font-size-18">Merchants profile</h4>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Merchant profile setting</a></li>
                </ol>
            </div>
        </div>

    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-xl-4">
            <div class="card">
                <div class="card header">
                    <img class="img-thumbnail" src="" alt="profile image">
                </div>
                <div class="card-body text-center">
                    <h4> Name: <?php echo e($result->merchant_name); ?></h4>
                    <h6> Phone: <?php echo e($result->merchant_phone); ?></h6>
                    <h6> Email: <?php echo e($result->merchant_email); ?></h6>
                    <h6> Active Status: <?php if($result->active_status==0): ?> NO <?php else: ?> YES <?php endif; ?></h6>
                    <h6> COD Enable: <?php if($result->is_cod_enable==0): ?> No <?php else: ?> yes <?php endif; ?></h6>
                    <h6> COD Charge: <?php echo e($result->cod_charge); ?></h6>
                    <h6> Area: <?php echo e($results->area_name); ?></h6>
                </div>
            </div>
        </div>
        <div class="col-xl-8">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4">Latest Parcel</h4>
                    <div class="table-responsive">
                        <table class="table table-hover table-centered table-nowrap mb-0">
                            <thead>
                            <tr>
                                <th scope="col"> Invoice </th>
                                <th scope="col">Name</th>
                                <th scope="col">Date</th>
                                <th scope="col">Amount</th>
                                <th scope="col" colspan="2">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <?php $__currentLoopData = $parcel_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th scope="row"><?php echo e($list->parcel_invoice); ?></th>
                                    <td>

                                        <?php echo e($list->customer_name); ?>


                                    </td>
                                    <td><?php echo e($list->delivery_date); ?></td>
                                    <td><?php echo e($list->total_amount); ?></td>
                                    <td><span class="badge badge-success"><?php echo e($list->delivery_status); ?></span></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-title">
                    <h5 class="mt-2 text-center text-success"> Payment Methoed Details</h5>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $payment_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h6> <strong>Payment Method :</strong> <?php echo e($data->payment_methoed_name); ?></h6>
                        <h6> <strong>Account Number:</strong> <?php echo e($data->account_number); ?></h6>
                        <h6> <strong>Branch Addrss:</strong> <?php echo e($data->branch_address); ?></h6>
                        <h6> <strong>Payee Name:</strong> <?php echo e($data->payee_name); ?></h6>




                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>


                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Babu09\Downloads\joldi\resources\views/admin/merchant/profile.blade.php ENDPATH**/ ?>
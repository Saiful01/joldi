<?php

function statusFormat($status)
{

    return ucfirst(str_replace('_', ' ', $status));;
}





//https://stackoverflow.com/questions/28290332/best-practices-for-custom-helpers-in-laravel-5
?>
@extends('layouts.default')

@section('content')
  <div class="container-fluid mt-5 ">
      <div class="row">
          <div class="col-md-6">
              <h1 class="text-success"> Welcome To Our Courier Service</h1>

          </div>
          <div class="col-md-6">
              <img src="/assets/images/cycle-landing-min.png" alt="Image" class="img-fluid">
          </div>
      </div>
  </div>


@endsection

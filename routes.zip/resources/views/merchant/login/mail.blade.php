<h1>Hello {{$user->merchant_name}}</h1>
<p>
    Please Click the Reset Button To Reset your password
    <a href="/merchant/confirmpassword">Click here Reset password</a>
</p>

<?php


namespace App\Http\Controllers;


class Sentinel
{

    public static function findById($id)
    {
    }
}

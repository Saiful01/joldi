<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ParcelStatusHistory extends Model
{

    public $timestamps=true;
    protected $guarded=[];
}

<?php

namespace App\Http\Controllers;

use App\ParcelStatus;
use Illuminate\Http\Request;

class ParcelStatusController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ParcelStatus  $parcelStatus
     * @return \Illuminate\Http\Response
     */
    public function show(ParcelStatus $parcelStatus)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ParcelStatus  $parcelStatus
     * @return \Illuminate\Http\Response
     */
    public function edit(ParcelStatus $parcelStatus)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ParcelStatus  $parcelStatus
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ParcelStatus $parcelStatus)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ParcelStatus  $parcelStatus
     * @return \Illuminate\Http\Response
     */
    public function destroy(ParcelStatus $parcelStatus)
    {
        //
    }
}

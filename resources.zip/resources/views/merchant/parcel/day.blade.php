<div class="card card-body pickupOptions border-0 p-2">
    <div class="row">
        <div class="col-6"><a href="">
                <div class="card info-card border-0 my-3 cursor-pointer">
                    <div class="card-body rounded">
                        <div class="text-center over-badge"><span class="content">24h</span></div>
                        <p class="font-13 mb-0 text-center line-height-1_25 lbl">Next Day</p>
                        <p class="font-12 text-center line-height-1_25 mb-0 opacity-7_5">Delivery</p></div>
                </div>
            </a>
            <div class="text-center "><a href="https://www.steadfastcourier.com/user/pricing/next-day">See Pricing</a>
            </div>
        </div>
        <div class="col-6"><a href="">
                <div class="card info-card border-0 my-3 cursor-pointer">
                    <div class="card-body rounded">
                        <div class="text-center over-badge"><span class="content">12h</span></div>
                        <p class="font-13 mb-0 text-center line-height-1_25 lbl">Same Day</p>
                        <p class="font-12 text-center line-height-1_25 mb-0 opacity-7_5">Delivery</p></div>
                </div>
            </a>
            <div class="">See Pricing</a>
            </div>
        </div>
    </div>
</div>

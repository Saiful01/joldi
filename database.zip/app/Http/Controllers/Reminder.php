<?php


namespace App\Http\Controllers;


class Reminder
{

}

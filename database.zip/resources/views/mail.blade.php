<h1>Hi! {{$name}}</h1>
<p>{{$body}}</p>
